/*
    ufiformat Version 0.1 2005/01/14

    Copyright (C) 2005 Kazuhiro Hayashi <tedi@tedi.sakura.ne.jp>

    The method of formatting a floppy on USB-FDD used by this program
    is introduced by Bruce M Simpson.

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <scsi/sg.h>
#include <scsi/scsi.h>

#define TIMEOUT (100 * 1000)	/* milliseconds */
#define BLOCK 2880		/* sectors per disk */
#define BLOCK_SIZE 512		/* bytes per sector */

/* UFI format command */
unsigned char FORMAT_CMD[] = {
    FORMAT_UNIT, 0x17, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

/* UFI format data */
unsigned char FORMAT_DATA[] = {
    0x00, 0xA0, 0x00, 0x08,
    BLOCK >> 24, (BLOCK >> 16) & 0xFF, (BLOCK >> 8) & 0xFF, BLOCK & 0xFF,
    00,
    BLOCK_SIZE >> 16, (BLOCK_SIZE >> 8) & 0xFF, BLOCK_SIZE & 0xFF
};

int main(int argc, char **argv) {
    int fd;
    sg_io_hdr_t sg_io_hdr;
    unsigned char sense_buffer[32];

    if (argc != 2) {
	fprintf(stderr, "usage: %s device\n", argv[0]);
	exit(1);
    }
    if ((fd = open(argv[1], O_RDWR)) < 0) {
	perror("open");
	exit(1);
    }

    memset(&sg_io_hdr, 0, sizeof(sg_io_hdr));
    sg_io_hdr.interface_id = 'S';
    sg_io_hdr.cmdp = FORMAT_CMD;
    sg_io_hdr.cmd_len = sizeof(FORMAT_CMD);
    sg_io_hdr.dxfer_direction = SG_DXFER_TO_DEV;
    sg_io_hdr.dxferp = FORMAT_DATA;
    sg_io_hdr.dxfer_len = sizeof(FORMAT_DATA);
    sg_io_hdr.sbp = sense_buffer;
    sg_io_hdr.mx_sb_len = sizeof(sense_buffer);
    sg_io_hdr.timeout = TIMEOUT;

    if (ioctl(fd, SG_IO, &sg_io_hdr) < 0) {
	perror("ioctl(SG_IO)");
	close(fd);
	exit(1);
    }
    if ((sg_io_hdr.info & SG_INFO_OK_MASK) != SG_INFO_OK) {
	fprintf(stderr, "SCSI error(info=%x)\n", (sg_io_hdr.info & SG_INFO_OK_MASK));
	close(fd);
	exit(1);
    }
    close(fd);
    exit(0);
}
